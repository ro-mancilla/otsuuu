from Config.Singleton import Singleton
from Config.Configs import VConfigs
from Config.Emojis import VEmojis


class Messages(Singleton):
    def __init__(self) -> None:
        if not super().created:
            self.__emojis = VEmojis()
            configs = VConfigs()
            self.STARTUP_MESSAGE = 'Iniciando OTSU2...'
            self.STARTUP_COMPLETE_MESSAGE = '¡OTSU2 preparado!'

            self.SONGINFO_UPLOADER = "Autor: "
            self.SONGINFO_DURATION = "Duración: "
            self.SONGINFO_REQUESTER = 'Agregado por: '
            self.SONGINFO_POSITION = 'Posición: '

            self.VOLUME_CHANGED = 'Volumen cambiado a `{}`%'
            self.SONGS_ADDED = 'Descargando `{}` canción(es)...'
            self.SONG_ADDED = 'Descargando `{}`...'
            self.SONG_ADDED_TWO = f'{self.__emojis.MUSIC}  ¡Música agregada a la cola!'
            self.SONG_PLAYING = f'{self.__emojis.MUSIC}  Reproduciendo... **~★**'
            self.SONG_PLAYER = f'{self.__emojis.DOWNLOADING}  Cola de música **~★**'
            self.QUEUE_TITLE = f'{self.__emojis.MUSIC}  Música en cola.'
            self.ONE_SONG_LOOPING = f'{self.__emojis.MUSIC}  Reproduciendo en bucle...'
            self.ALL_SONGS_LOOPING = f'{self.__emojis.MUSIC}  Reproduciendo en bucle todo...'
            self.SONG_PAUSED = f'{self.__emojis.PAUSE}  Música pausada.'
            self.SONG_RESUMED = f'{self.__emojis.PLAY}  Música reanudada.'
            self.SONG_SKIPPED = f'{self.__emojis.SKIP}  Música saltada.'
            self.RETURNING_SONG = f'{self.__emojis.BACK}  Reproduciendo música anterior.'
            self.STOPPING = f'{self.__emojis.STOP}  OTSU2 detenido.'
            self.EMPTY_QUEUE = f'{self.__emojis.QUEUE}  ¡La cola de música está vacía! Reproduce algo con `/play [URL]`.'
            self.SONG_DOWNLOADING = f'{self.__emojis.DOWNLOADING}  Descargando...'
            self.PLAYLIST_CLEAR = f'{self.__emojis.MUSIC}  La lista de reproducción está vacía.'

            self.HISTORY_TITLE = f'{self.__emojis.MUSIC}  Música en reproducción. **~★**'
            self.HISTORY_EMPTY = f'{self.__emojis.QUEUE}  No hay música en el historial. **~★**'

            self.SONG_MOVED_SUCCESSFULLY = '`{}` en la posición `{}` se movió a la posición `{}` correctamente. **~★**'
            self.SONG_REMOVED_SUCCESSFULLY = '`{}` eliminada. **~★**'

            self.LOOP_ALL_ON = f'{self.__emojis.ERROR}  OTSU2 está con el bucle activado, desactivalo con `/loop off`'
            self.LOOP_ONE_ON = f'{self.__emojis.ERROR}  OTSU2 está con el bucle de la música actual activado, desactivalo con `/loop off`'
            self.LOOP_ALL_ALREADY_ON = f'{self.__emojis.LOOP_ALL}  Ya está activado el bucle.'
            self.LOOP_ONE_ALREADY_ON = f'{self.__emojis.LOOP_ONE}  Ya está activado el bucle de la música actual.'
            self.LOOP_ALL_ACTIVATE = f'{self.__emojis.LOOP_ALL}  Bucle activado. **~★**'
            self.LOOP_ONE_ACTIVATE = f'{self.__emojis.LOOP_ONE}  Bucle de la música actual activado. **~★**'
            self.LOOP_DISABLE = f'{self.__emojis.LOOP_OFF}  Bucle desactivado.'
            self.LOOP_ALREADY_DISABLE = f'{self.__emojis.ERROR}  Ya está desactivado el bucle.'
            self.LOOP_ON = f'{self.__emojis.ERROR}  Este comando no se puede activar cuando cualquier bucle esté activado. Escribe `/loop off` para desactivar el bucle.'
            self.BAD_USE_OF_LOOP = f'{self.__emojis.ERROR}  Mal uso del comando de bucle.\nValores posibles: [off], [one] y [all]'

            self.SONGS_SHUFFLED = f'{self.__emojis.SHUFFLE}  Música mezclada. **~★**'
            self.ERROR_SHUFFLING = f'{self.__emojis.ERROR}  Hubo un problema al intentar mezclar la música...'
            self.ERROR_MOVING = f'{self.__emojis.ERROR}  Hubo un problema al intentar mover la música...'
            self.LENGTH_ERROR = f'{self.__emojis.ERROR}  Los valores deben estar entre 1 y el tamaño de la cola.'
            self.ERROR_NUMBER = f'{self.__emojis.ERROR}  Este comando requiere un valor...'
            self.ERROR_VOLUME_NUMBER = f'{self.__emojis.ERROR}  Este comando requiere un valor entre 0 y 100.'
            self.ERROR_PLAYING = f'{self.__emojis.ERROR}  Hubo un problema al intentar reproducir la música...'
            self.COMMAND_NOT_FOUND = f'{self.__emojis.ERROR}  Comando no válido... Escribe `/` para ver todos mis comandos.'
            self.UNKNOWN_ERROR = f'{self.__emojis.ERROR}  Ocurrió un error desconocido. Intenta reiniciarme con `/reset` para intentar solucionar el problema...'
            self.ERROR_MISSING_ARGUMENTS = f'{self.__emojis.ERROR}  Faltan argumentos para ese comando... Escribe `/` para ver todos mis comandos.'
            self.NOT_PREVIOUS = f'{self.__emojis.ERROR}  No hay música anteriormente reproducida.'
            self.PLAYER_NOT_PLAYING = f'{self.__emojis.ERROR}  No hay ninguna música en reproducción... ¡Empecemos a escuchar música con `/play`!'
            self.IMPOSSIBLE_MOVE = 'Hiciste a OTSU2 llorar por tu comando...'
            self.ERROR_TITLE = 'Error...'
            self.COMMAND_NOT_FOUND_TITLE = 'Error...'
            self.NO_CHANNEL = '¡Conectate a un chat de voz para que empecemos a escuchar música!'
            self.NO_GUILD = f'OTSU2 no está actualmente activo, intenta reiniciame con `/reset`...'
            self.INVALID_INPUT = f'URL no válida...'
            self.INVALID_INDEX = f'Argumento inválido.'
            self.INVALID_ARGUMENTS = f'Argumentos inválidos.'
            self.DOWNLOADING_ERROR = f"{self.__emojis.ERROR}  ¡No puedo descargar la URL que especificaste!"
            self.EXTRACTING_ERROR = f'{self.__emojis.ERROR}  ¡Hubo un error al buscar la música que especificaste!'

            self.ERROR_IN_PROCESS = f"{self.__emojis.ERROR}  Debido a un error interno, OTSU2 reinició la reproducción."
            self.MY_ERROR_BAD_COMMAND = 'This string serves to verify if some error was raised by myself on purpose'
            self.BAD_COMMAND_TITLE = 'Mal uso del comando...'
            self.BAD_COMMAND = f'{self.__emojis.ERROR}  Mal uso del comando... Escribe `/` para ver todos mis comandos.'
            self.VIDEO_UNAVAILABLE = f'{self.__emojis.ERROR}  Lo siento, la URL que especificaste no está disponible para que la pueda descargar...'
            self.ERROR_DUE_LOOP_ONE_ON = f'{self.__emojis.ERROR}  No se puede usar este comando cuando el bucle de una canción esta activado. Escribe `/loop off` para desactivar el bucle.'


class SearchMessages(Singleton):
    def __init__(self) -> None:
        if not super().created:
            config = VConfigs()
            self.UNKNOWN_INPUT = f'Error...'
            self.UNKNOWN_INPUT_TITLE = 'Error...'
            self.GENERIC_TITLE = 'Error...'
            self.SPOTIFY_NOT_FOUND = 'URL de Spotify no válida, revisa que tenga este formato:\nhttps://open.spotify.com/track/XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
            self.YOUTUBE_NOT_FOUND = 'URL de YouTube no válida, revisa que tenga este formato:\nhttps://www.youtube.com/watch?v=XXXXXXXXXXX'
            self.DEEZER_NOT_FOUND = 'Deezer could not process any songs with this input, verify your link or try again later.'


class SpotifyMessages(Singleton):
    def __init__(self) -> None:
        if not super().created:
            self.INVALID_SPOTIFY_URL = 'URL de Spotify inválida. Revisa que esté en el siguiente formato: \nhttps://open.spotify.com/track/XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
            self.GENERIC_TITLE = 'URL could not be processed'


class DeezerMessages(Singleton):
    def __init__(self) -> None:
        if not super().created:
            self.INVALID_DEEZER_URL = 'Invalid Deezer URL, verify your link.'
            self.GENERIC_TITLE = 'URL could not be processed'
