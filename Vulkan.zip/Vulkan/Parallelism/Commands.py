from enum import Enum
from typing import Tuple


class VCommandsType(Enum):
    PREV = 'Anterior'
    SKIP = 'Saltar'
    PAUSE = 'Pausar'
    RESUME = 'Reanudar'
    CONTEXT = 'Contexto'
    PLAY = 'Reproducir'
    STOP = 'Detener'
    RESET = 'Reiniciar'
    NOW_PLAYING = 'Reproduciendo'
    TERMINATE = 'Terminar'
    VOLUME = 'Volumen'
    SLEEPING = 'Ausente'


class VCommands:
    def __init__(self, type: VCommandsType, args=None) -> None:
        self.__type = type
        self.__args = args

    def getType(self) -> VCommandsType:
        return self.__type

    def getArgs(self) -> Tuple:
        return self.__args
